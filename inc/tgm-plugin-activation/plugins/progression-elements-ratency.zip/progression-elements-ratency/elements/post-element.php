<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.


class Widget_ProgressionElementsReviewList extends Widget_Base {

	
	public function get_name() {
		return 'progression-review-post-list';
	}

	public function get_title() {
		return esc_html__( 'Post List - Ratency', 'progression-elements-ratency' );
	}

	public function get_icon() {
		return 'eicon-post-list progression-studios-ratency-pe';
	}

   public function get_categories() {
		return [ 'progression-elements-ratency-cat' ];
	}
	
	
	function Widget_ProgressionElementsReviewList($widget_instance){
		
	}
	
	protected function _register_controls() {

		
  		$this->start_controls_section(
  			'section_title_global_options',
  			[
  				'label' => esc_html__( 'Post Settings', 'progression-elements-ratency' )
  			]
  		);
		
		$this->add_control(
			'progression_main_post_count',
			[
				'label' => esc_html__( 'Post Count', 'progression-elements-ratency' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '6',
			]
		);
		
		$this->add_responsive_control(
			'progression_elements_image_grid_column_count',
			[
  				'label' => esc_html__( 'Columns', 'progression-elements-ratency' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,				
				'desktop_default' => '50%',
				'tablet_default' => '50%',
				'mobile_default' => '100%',
				'options' => [
					'100%' => esc_html__( '1 Column', 'progression-elements-ratency' ),
					'50%' => esc_html__( '2 Column', 'progression-elements-ratency' ),
					'33.330%' => esc_html__( '3 Columns', 'progression-elements-ratency' ),
					'25%' => esc_html__( '4 Columns', 'progression-elements-ratency' ),
					'20%' => esc_html__( '5 Columns', 'progression-elements-ratency' ),
					'16.67%' => esc_html__( '6 Columns', 'progression-elements-ratency' ),
				],
				'selectors' => [
					'{{WRAPPER}} .progression-masonry-item' => 'width: {{VALUE}};',
				],
				'render_type' => 'template'
			]
		);
		
		
  		$this->add_responsive_control(
  			'progression_elements_image_grid_margin',
  			[
  				'label' => esc_html__( 'Margin', 'progression-elements-ratency' ),
  				'type' => Controls_Manager::SLIDER,
				'default' => [
					'size' => 20,
				],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .progression-masonry-margins' => 'margin-left:-{{SIZE}}px; margin-right:-{{SIZE}}px;',
					'{{WRAPPER}} .progression-masonry-padding-blog' => 'padding: {{SIZE}}px;',
				],
				'render_type' => 'template'
  			]
  		);
		
		
		
		$this->add_control(
			'boosted_post_list_masonry',
			[
				'label' => esc_html__( 'Masonry Layout', 'progression-elements-progression' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_list_pagination',
			[
				'label' => esc_html__( 'Post Pagination', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'no-pagination',
				'options' => [
					'no-pagination' => esc_html__( 'No Pagination', 'progression-elements-ratency' ),
					'default' => esc_html__( 'Default Pagination', 'progression-elements-ratency' ),
					'load-more' => esc_html__( 'Load More Posts', 'progression-elements-ratency' ),
					'infinite-scroll' => esc_html__( 'Inifinite Scroll', 'progression-elements-ratency' ),
				],
			]
		);
		
		$this->add_control(
			'progression_main_post_load_more',
			[
				'label' => esc_html__( 'Load More Text', 'progression-elements-ratency' ),
				'type' => Controls_Manager::TEXT,
				'default' => 'Load More',
				'condition' => [
					'progression_elements_post_list_pagination' => 'load-more',
				],
			]
		);

		
		$this->end_controls_section();
		
		
  		$this->start_controls_section(
  			'section_title_layout_options',
  			[
  				'label' => esc_html__( 'Post Layout', 'progression-elements-ratency' )
  			]
  		);

		
		$this->add_control(
			'progression_elements_post_layout',
			[
				'label' => esc_html__( 'Post Layout', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'top-image',
				'options' => [
					'default' => esc_html__( 'Left Image', 'progression-elements-ratency' ),
					'top-image' => esc_html__( 'Top Image', 'progression-elements-ratency' ),
					'overlay' => esc_html__( 'Overlay', 'progression-elements-ratency' ),
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_show_image',
			[
				'label' => esc_html__( 'Display Image', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_show_review',
			[
				'label' => esc_html__( 'Review Rating', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'progression_elements_post_display_author',
			[
				'label' => esc_html__( 'Author', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_date',
			[
				'label' => esc_html__( 'Display Date', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_category',
			[
				'label' => esc_html__( 'Display Category', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_comments',
			[
				'label' => esc_html__( 'Display Comments', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->add_control(
			'progression_elements_post_display_excerpt',
			[
				'label' => esc_html__( 'Display Excerpt', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		

		
		

		
		$this->end_controls_section();
		
		
  		$this->start_controls_section(
  			'section_title_secondary_options',
  			[
  				'label' => esc_html__( 'Post Query', 'progression-elements-ratency' )
  			]
  		);
		
		
		$this->add_control(
			'progression_slider_tags',
			[
				'label' => esc_html__( 'Narrow by Filtering Tags', 'progression-elements-ratency' ),
				'description' => esc_html__( 'Choose a filtering tag to display posts', 'progression-elements-ratency' ),
				'label_block' => true,
				'multiple' => true,
				'type' => Controls_Manager::SELECT2,
				'options' => ratency_elements_post_type_slider_tags(),
			]
		);
		
		$this->add_control(
			'progression_slider_cats',
			[
				'label' => esc_html__( 'Narrow by Category', 'progression-elements-ratency' ),
				'description' => esc_html__( 'Choose a category to display posts', 'progression-elements-ratency' ),
				'label_block' => true,
				'multiple' => true,
				'type' => Controls_Manager::SELECT2,
				'options' => ratency_elements_post_type_categories(),
			]
		);
		
		
		
		
		$this->add_control(
			'progression_elements_post_order_sorting',
			[
				'label' => esc_html__( 'Order By', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'date',
				'options' => [
					'date' => esc_html__( 'Default - Date', 'progression-elements-ratency' ),
					'post_views' => esc_html__( 'Views - All Time', 'progression-elements-viseo' ),
					'post_views_year' => esc_html__( 'Views - Per Year', 'progression-elements-viseo' ),
					'post_views_month' => esc_html__( 'Views - Per Month', 'progression-elements-viseo' ),
					'post_views_day' => esc_html__( 'Views - Per Day', 'progression-elements-viseo' ),
					'title' => esc_html__( 'Post Title', 'progression-elements-ratency' ),
					'menu_order' => esc_html__( 'Menu Order', 'progression-elements-ratency' ),
					'modified' => esc_html__( 'Last Modified', 'progression-elements-ratency' ),
					'comment_count' => esc_html__( 'Comment Count', 'progression-elements-viseo' ),
					'rand' => esc_html__( 'Random', 'progression-elements-ratency' ),
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_post_order',
			[
				'label' => esc_html__( 'Order', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'ASC' => esc_html__( 'Ascending', 'progression-elements-ratency' ),
					'DESC' => esc_html__( 'Descending', 'progression-elements-ratency' ),
				],
			]
		);
		
		$this->add_control(
			'progression_main_offset_count',
			[
				'label' => esc_html__( 'Offset Count', 'progression-elements-ratency' ),
				'type' => Controls_Manager::NUMBER,
				'default' => '0',
				'description' => esc_html__( 'Use this to skip over posts (Example: 3 would skip the first 3 posts.)', 'progression-elements-ratency' ),
			]
		);
	
		
		
		$this->add_control(
			'progression_elements_slider_sorting_on',
			[
				'label' => esc_html__( 'Filtering Sorting', 'progression-elements-ratency' ),
				'description' => esc_html__( 'Sort by Filtering Tags', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);
		
		
		$this->add_control(
			'progression_elements_category_sorting_on',
			[
				'label' => esc_html__( 'Category Sorting', 'progression-elements-ratency' ),
				'description' => esc_html__( 'Sort by Post Categories', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		
		$this->add_control(
			'progression_elements_category_sorting_text',
			[
				'label' => esc_html__( 'Sorting Text for All Posts', 'progression-elements-ratency' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'All', 'progression-elements-ratency' ),
			]
		);
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'progression_elements_section_main_styles',
			[
				'label' => esc_html__( 'Main Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		

		
		
		$this->add_control(
			'progression_elements_image_background_color',
			[
				'label' => esc_html__( 'Main Border Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-blog-content, {{WRAPPER}} .progression-studios-default-blog-top .blog-post-vertical-content-layout' => 'border-color: {{VALUE}}',
				],
			]
		);
		
		
  		$this->add_responsive_control(
  			'progression_elements_min_height_overlay',
  			[
  				'label' => esc_html__( 'Minimum Height (Overlay)', 'progression-elements-ratency' ),
  				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 800,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .progression-studios-default-blog-overlay, .overlay-progression-blog-content' => 'min-height:{{SIZE}}px;',
				],
				'render_type' => 'template'
  			]
  		);

		
		$this->add_responsive_control(
			'progression_elements_content_padding',
			[
				'label' => esc_html__( 'Content Padding', 'progression-elements-ratency' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .progression-studios-default-blog-top .blog-post-vertical-content-layout, {{WRAPPER}} .overlay-progression-blog-content-padding, {{WRAPPER}} .progression-studios-float-blog-content-padding' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'progression_elements_background_overlay',
				'types' => [ 'classic', 'gradient' ],
				'separator' => 'before',
				'selector' => '{{WRAPPER}} .progression-studios-default-blog-top .blog-post-vertical-content-layout, {{WRAPPER}} .progression-studios-default-blog-left,{{WRAPPER}}  .overlay-blog-gradient',
			]
		);
		
		

		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_styles_review_styles',
			[
				'label' => esc_html__( 'Review Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_review_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-ratency' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .progression-blog-review-index-total',
			]
		);
		
		$this->add_control(
			'boosted_elements_reivew_font_color',
			[
				'label' => esc_html__( 'Review Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-blog-review-index-total' => 'color: {{VALUE}};',
				],
			]
		);
		
		
		$this->add_control(
			'boosted_elements_reivew_border',
			[
				'label' => esc_html__( 'Review Border Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-studios-index-hexagon-border' => 'background: {{VALUE}};',
					'{{WRAPPER}} .progression-studios-index-hexagon-border:before' => 'border-bottom-color: {{VALUE}};',
					'{{WRAPPER}} .progression-studios-index-hexagon-border:after' => 'border-top-color: {{VALUE}};',
				],
			]
		);
		
		$this->add_control(
			'boosted_elements_reivew_background_color',
			[
				'label' => esc_html__( 'Review Background Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-blog-review-index-total' => 'background: {{VALUE}};',
					'{{WRAPPER}} .progression-blog-review-index-total:before' => 'border-bottom-color: {{VALUE}};',
					'{{WRAPPER}} .progression-blog-review-index-total:after' => 'border-top-color: {{VALUE}};',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'boosted_elements_review_margin_bottom',
			[
				'label' => esc_html__( 'Review Margin Bottom', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .progression-studios-hexagon-index-container' => 'padding-bottom: {{SIZE}}px;',
				],
			]
		);
		
		$this->end_controls_section();
		
		
		
		$this->start_controls_section(
			'section_styles_category_styles',
			[
				'label' => esc_html__( 'Category Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		
		$this->add_responsive_control(
			'progression_elements_category_padding',
			[
				'label' => esc_html__( 'Category Padding', 'progression-elements-ratency' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .blog-meta-category-list a, {{WRAPPER}} .overlay-blog-meta-category-list a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_category_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-ratency' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .blog-meta-category-list a, {{WRAPPER}} .overlay-blog-meta-category-list a',
			]
		);
		
		
		
		
		$this->start_controls_tabs( 'boosted_elements_category_tabs' );

		$this->start_controls_tab( 'boosted_elements_category_normal', [ 'label' => esc_html__( 'Normal', 'progression-elements-ratency' ) ] );

		$this->add_control(
			'boosted_elements_cat_button_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-meta-category-list a, {{WRAPPER}} .overlay-blog-meta-category-list a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_cat_button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-meta-category-list a, {{WRAPPER}} .overlay-blog-meta-category-list a' => 'background-color: {{VALUE}};',
				],
			]
		);

		
		$this->end_controls_tab();

		$this->start_controls_tab( 'boosted_elements_cat_hover', [ 'label' => esc_html__( 'Hover', 'progression-elements-ratency' ) ] );

		$this->add_control(
			'boosted_elements_bcat_utton_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-meta-category-list a:hover, {{WRAPPER}} .overlay-blog-meta-category-list a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_cat_button_hover_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .blog-meta-category-list a:hover, {{WRAPPER}} .overlay-blog-meta-category-list a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		
		
		$this->add_responsive_control(
			'boosted_elements_category_margin_bottom',
			[
				'label' => esc_html__( 'Category Margin Bottom', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .blog-meta-category-list' => 'margin-bottom: {{SIZE}}px;',
				],
			]
		);
		

		$this->end_controls_section();
		
		
		
		
		$this->start_controls_section(
			'section_styles_title_styles',
			[
				'label' => esc_html__( 'Title Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_title_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-ratency' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} h2.progression-blog-title, {{WRAPPER}} h2.overlay-progression-blog-title',
			]
		);
		
		$this->add_control(
			'boosted_elements_title_font_color',
			[
				'label' => esc_html__( 'Title Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h2.progression-blog-title a, {{WRAPPER}} h2.overlay-progression-blog-title' => 'color: {{VALUE}};',
				],
			]
		);
		
		
		$this->add_control(
			'boosted_elements_title_hover_font_color',
			[
				'label' => esc_html__( 'Title Hover Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h2.progression-blog-title a:hover, {{WRAPPER}} h2.overlay-progression-blog-title:hover' => 'color: {{VALUE}};',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'boosted_elements_title_margin_bottom',
			[
				'label' => esc_html__( 'Title Margin Bottom', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -20,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} h2.progression-blog-title, {{WRAPPER}} h2.overlay-progression-blog-title' => 'margin-bottom: {{SIZE}}px;',
				],
			]
		);
		
		
		
		$this->end_controls_section();
		
		
		
		$this->start_controls_section(
			'section_styles_meta_styles',
			[
				'label' => esc_html__( 'Meta/Excerpt Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'boosted_elements_heading_meta',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Meta', 'boosted-elements-progression' ),
				'separator' => 'after',
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_meta_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-ratency' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} ul.progression-post-meta li, {{WRAPPER}} ul.progression-studio-overlay-post-meta li',
			]
		);
		
		$this->add_control(
			'progression_elements_meta_font_color',
			[
				'label' => esc_html__( 'Meta Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-post-meta li, {{WRAPPER}} ul.progression-post-meta li a, {{WRAPPER}} ul.progression-studio-overlay-post-meta li' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_meta_margin_bottom',
			[
				'label' => esc_html__( 'Meta Margin Bottom', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -20,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} ul.progression-post-meta, {{WRAPPER}} ul.progression-studio-overlay-post-meta' => 'margin-bottom: {{SIZE}}px;',
				],
			]
		);
		
		
		
		$this->add_control(
			'boosted_elements_heading_Excerpt',
			[
				'type' => Controls_Manager::HEADING,
				'label' => esc_html__( 'Excerpt', 'boosted-elements-progression' ),
				'separator' => 'after',
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_escerpt_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-ratency' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .progression-studios-blog-excerpt, {{WRAPPER}} .overlay-progression-studios-excerpt',
			]
		);
		
		
		$this->add_control(
			'progression_elements_excerpt_font_color',
			[
				'label' => esc_html__( 'Excerpt Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .progression-studios-blog-excerpt, {{WRAPPER}} .overlay-progression-studios-excerpt' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_excerpt_margin_bottom',
			[
				'label' => esc_html__( 'Excerpt Margin Bottom', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -50,
						'max' => 150,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .progression-studios-blog-excerpt, {{WRAPPER}} .overlay-progression-studios-excerpt' => 'margin-bottom: {{SIZE}}px;',
				],
			]
		);
		
		$this->end_controls_section();
		
		
		$this->start_controls_section(
			'section_styles_load_more_styles',
			[
				'label' => esc_html__( 'Load More Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'section_styles_load_more_icon',
			[
				'type' => Controls_Manager::ICON,
				'label_block' => true,
				'default' => 'fa-arrow-circle-down',
			]
		);
		
		$this->add_control(
			'section_styles_load_more_icon_indent',
			[
				'label' => esc_html__( 'Icon Spacing', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'max' => 50,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a span i' => 'margin-left: {{SIZE}}px;',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'progression_elements_load_more_padding',
			[
				'label' => esc_html__( 'Padding', 'progression-elements-ratency' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_load_moretypography',
				'label' => esc_html__( 'Typography', 'progression-elements-ratency' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .infinite-nav-pro a',
			]
		);
		
		
		
		
		$this->start_controls_tabs( 'boosted_elements_button_tabs' );

		$this->start_controls_tab( 'normal', [ 'label' => esc_html__( 'Normal', 'progression-elements-ratency' ) ] );

		$this->add_control(
			'boosted_elements_button_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_button_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a' => 'background-color: {{VALUE}};',
				],
			]
		);

		
		$this->end_controls_tab();

		$this->start_controls_tab( 'boosted_elements_hover', [ 'label' => esc_html__( 'Hover', 'progression-elements-ratency' ) ] );

		$this->add_control(
			'boosted_elements_button_hover_text_color',
			[
				'label' => esc_html__( 'Text Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'boosted_elements_button_hover_background_color',
			[
				'label' => esc_html__( 'Background Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .infinite-nav-pro a:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		
		
		
		$this->start_controls_section(
			'section_styles_filter_styles',
			[
				'label' => esc_html__( 'Filtering Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_responsive_control(
			'boosted_elements_filtering_align',
			[
				'label' => esc_html__( 'Filtering Alignment', 'progression-elements-ratency' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'progression-elements-ratency' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'progression-elements-ratency' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'progression-elements-ratency' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group' => 'text-align: {{VALUE}}',
				],
			]
		);
		

		
		$this->add_control(
			'progression_elements_filter_font_color',
			[
				'label' => esc_html__( 'Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_filter_font_selected_color',
			[
				'label' => esc_html__( 'Selected Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li.pro-checked' => 'color: {{VALUE}}',
					'{{WRAPPER}} ul.progression-filter-button-group li:hover' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_filter_border_color',
			[
				'label' => esc_html__( 'Default Border', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group:after' => 'background: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_filter_font_selected_border_color',
			[
				'label' => esc_html__( 'Selected Border', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li.pro-checked:after' => 'background: {{VALUE}}',
					'{{WRAPPER}} ul.progression-filter-button-group li:hover:after' => 'background: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'progression_elements_fliltering_padding',
			[
				'label' => esc_html__( 'Padding', 'progression-elements-ratency' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'progression_elements_fliltering_margin',
			[
				'label' => esc_html__( 'Margin', 'progression-elements-ratency' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} ul.progression-filter-button-group li' => 'Margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_filtering_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-ratency' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} ul.progression-filter-button-group li',
			]
		);
		
		$this->end_controls_section();
		
	}
	

	protected function render( ) {
		
      $settings = $this->get_settings();


	global $blogloop;
	global $post;
	
	if ( get_query_var('paged') ) { $paged = get_query_var('paged'); } else if ( get_query_var('page') ) {   $paged = get_query_var('page'); } else {  $paged = 1; }
	

	$post_per_page = $settings['progression_main_post_count'];
	$offset = $settings['progression_main_offset_count'];
	$offset_new = $offset + (( $paged - 1 ) * $post_per_page);
	
	
	
		
	if ( ! empty( $settings['progression_slider_tags'] ) ) {
		$formattagarray = $settings['progression_slider_tags']; // get custom field value
		
		$tagarray = $settings['progression_slider_tags']; // get custom field value
		if($tagarray >= 1 ) { 
			$cattagidss = implode(', ', $tagarray); 
		} else {
			$cattagidss = '';
		}
		
		if($formattagarray >= 1) { 
			$formatagids = implode(', ', $formattagarray);
         $formatagidsexpand = explode(', ', $formatagids);
			$formatotagperator = 'IN'; 
		} else {
			$formatagidsexpand = '';
			$formatotagperator = 'NOT IN'; 
		}
		$tagoperator = 'IN';
 	} else {

	 		$formatagidsexpand = '';
			$tagoperator = 'NOT IN';
 	}
		
		

	if ( ! empty( $settings['progression_slider_cats'] ) ) {
		$formatarray = $settings['progression_slider_cats']; // get custom field value
		
		$catarray = $settings['progression_slider_cats']; // get custom field value
		if($catarray >= 1 ) { 
			$catids = implode(', ', $catarray); 
		} else {
			$catids = '';
		}
		
		if($formatarray >= 1) { 
			$formatids = implode(', ', $formatarray);
         $formatidsexpand = explode(', ', $formatids);
			$formatoperator = 'IN'; 
		} else {
			$formatidsexpand = '';
			$formatoperator = 'NOT IN'; 
		}
		$operator = 'IN';
 	} else {

	 		$formatidsexpand = '';
			$operator = 'NOT IN';
 	}
	
	

	if ( $settings['progression_elements_post_order_sorting'] == 'post_views_year' ) {
		
	 	$args = array(
	 	        'post_type'         => 'post',
				  'orderby'         => $settings['progression_elements_post_order_sorting'],
				  'order'         => $settings['progression_elements_post_order'],
				  'ignore_sticky_posts' => 1,
				  'posts_per_page'     =>  $post_per_page,
				  'paged' => $paged,
				  'offset' => $offset_new,
				  'views_query'		=> array(
					  'year'	=> date( 'Y' ), // this year
				  ),
				  'tax_query' => array(
					  'relation' => 'AND',
			        array(
			            'taxonomy' => 'category',
			            'field'    => 'id',
			            'terms'    => $formatidsexpand,
							'operator' => $operator
			        ),
			        array(
		            'taxonomy' => 'slider-tags',
			            'field'    => 'id',
			            'terms'    => $formatagidsexpand,
							'operator' => $tagoperator
			        ),
				  ),
	 	);
		
	} else {
		if ( $settings['progression_elements_post_order_sorting'] == 'post_views_month' ) {
			
		 	$args = array(
		 	        'post_type'         => 'post',
					  'orderby'         => $settings['progression_elements_post_order_sorting'],
					  'order'         => $settings['progression_elements_post_order'],
					  'ignore_sticky_posts' => 1,
					  'posts_per_page'     =>  $post_per_page,
					  'paged' => $paged,
					  'offset' => $offset_new,
					  'views_query'		=> array(
						  'month' => date( 'm' ), // this month
					  ),
					  'tax_query' => array(
						  'relation' => 'AND',
				        array(
				            'taxonomy' => 'category',
				            'field'    => 'id',
				            'terms'    => $formatidsexpand,
								'operator' => $operator
				        ),
				        array(
			            'taxonomy' => 'slider-tags',
				            'field'    => 'id',
				            'terms'    => $formatagidsexpand,
								'operator' => $tagoperator
				        ),
					  ),
		 	);
			
		} else {
			
			if ( $settings['progression_elements_post_order_sorting'] == 'post_views_day' ) {
				
			 	$args = array(
			 	        'post_type'         => 'post',
						  'orderby'         => $settings['progression_elements_post_order_sorting'],
						  'order'         => $settings['progression_elements_post_order'],
						  'ignore_sticky_posts' => 1,
						  'posts_per_page'     =>  $post_per_page,
						  'paged' => $paged,
						  'offset' => $offset_new,
						  'views_query'		=> array(
							  'day'	=> date( 'd' ), // this day
						  ),
						  'tax_query' => array(
							  'relation' => 'AND',
					        array(
					            'taxonomy' => 'category',
					            'field'    => 'id',
					            'terms'    => $formatidsexpand,
									'operator' => $operator
					        ),
					        array(
				            'taxonomy' => 'slider-tags',
					            'field'    => 'id',
					            'terms'    => $formatagidsexpand,
									'operator' => $tagoperator
					        ),
						  ),
			 	);
				
				} else {
		
				 	$args = array(
				 	        'post_type'         => 'post',
							  'orderby'         => $settings['progression_elements_post_order_sorting'],
							  'order'         => $settings['progression_elements_post_order'],
							  'ignore_sticky_posts' => 1,
							  'posts_per_page'     =>  $post_per_page,
							  'paged' => $paged,
							  'offset' => $offset_new,
							  'tax_query' => array(
								  'relation' => 'AND',
						        array(
						            'taxonomy' => 'category',
						            'field'    => 'id',
						            'terms'    => $formatidsexpand,
										'operator' => $operator
						        ),
						        array(
					            'taxonomy' => 'slider-tags',
						            'field'    => 'id',
						            'terms'    => $formatagidsexpand,
										'operator' => $tagoperator
						        ),
							  ),
				 	);
	
		}
	}
}
	
 	

	$blogloop = new \WP_Query( $args );
	?>
	

	
	<div class="progression-studios-elementor-review-container">
		
			<?php if($settings['progression_elements_category_sorting_on'] == 'yes' ): ?>
				<ul class="progression-filter-button-group progression-filter-group-<?php echo esc_attr($this->get_id()); ?> <?php if($settings['boosted_elements_filtering_align'] == 'center' ): ?> progression-centered-filte-filter-pro<?php endif ?>">
					<?php if($settings['progression_slider_cats']): ?>
						<?php
							$i = 0;
							$args = array(
							    'hide_empty'             => '0',
							    'include'              => $catids,
							); 
							$terms = get_terms( 'category', $args );
							if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
								echo '<li class="pro-checked" data-filter="*">' . $settings['progression_elements_category_sorting_text'] .'</li> ';	
			
								foreach ( $terms as $term ) { 
								if ($i == 0) {
								echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
								} else if ($i > 0)  {
								echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
								}
								$i++;
								}
							}	
						?>
					<?php else : ?>
						<?php
							$i = 0;
							$terms = get_terms( 'category', 'hide_empty=0' );
							if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
								echo '<li class="pro-checked" data-filter="*">' . $settings['progression_elements_category_sorting_text'] .'</li> ';	
				
								foreach ( $terms as $term ) { 
								if ($i == 0) {
								echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
								} else if ($i > 0)  {
								echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
								}
								$i++;
								}
							}	
						?>
					<?php endif ?>
				</ul>
			
				<div class="clearfix-pro"></div>
			<?php else : ?>
				<?php if($settings['progression_elements_slider_sorting_on'] == 'yes' ): ?>
					<ul class="progression-filter-button-group progression-filter-group-<?php echo esc_attr($this->get_id()); ?> <?php if($settings['boosted_elements_filtering_align'] == 'center' ): ?> progression-centered-filte-filter-pro<?php endif ?>">
						<?php if($settings['progression_slider_tags']): ?>
							<?php
								$i = 0;
								$args = array(
								    'hide_empty'             => '0',
								    'include'              => $cattagidss,
								); 
								$terms = get_terms( 'slider-tags', $args );
								if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
									echo '<li class="pro-checked" data-filter="*">' . $settings['progression_elements_category_sorting_text'] .'</li> ';	
			
									foreach ( $terms as $term ) { 
									if ($i == 0) {
									echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
									} else if ($i > 0)  {
									echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
									}
									$i++;
									}
								}	
							?>
						<?php else : ?>
							<?php
								$i = 0;
								$terms = get_terms( 'slider-tags', 'hide_empty=0' );
								if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
									echo '<li class="pro-checked" data-filter="*">' . $settings['progression_elements_category_sorting_text'] .'</li> ';	
				
									foreach ( $terms as $term ) { 
									if ($i == 0) {
									echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
									} else if ($i > 0)  {
									echo '<li data-filter=".'.$term->slug.'">' .$term->name .'</li> ';	
									}
									$i++;
									}
								}	
							?>
						<?php endif ?>
					</ul>
			
					<div class="clearfix-pro"></div>
				<?php endif ?>
			<?php endif ?>
	
		
		<div class="progression-masonry-margins">
			<div id="progression-review-index-masonry-<?php echo esc_attr($this->get_id()); ?>">
				<?php while($blogloop->have_posts()): $blogloop->the_post();?>
					
				<div class="progression-masonry-item <?php  $terms = get_the_terms( $post->ID , 'slider-tags' );  if ( !empty( $terms ) ) : 	foreach ( $terms as $term ) { 	$term_link = get_term_link( $term, 'slider-tags' ); if( is_wp_error( $term_link ) ) continue; echo " ". $term->slug ; }  endif; ?> <?php  $terms = get_the_terms( $post->ID , 'category' );  if ( !empty( $terms ) ) : 	foreach ( $terms as $term ) { 	$term_link = get_term_link( $term, 'category' ); if( is_wp_error( $term_link ) ) continue; echo " ". $term->slug ; }  endif; ?>">
					<div class="progression-masonry-padding-blog">
						<div class="progression-studios-isotope-animation">
							
							<?php if ( $settings['progression_elements_post_layout'] == 'default' ) : ?>
								<?php include(locate_template('template-parts/elementor/content.php')); ?>
							<?php endif; ?>
							
							<?php if ( $settings['progression_elements_post_layout'] == 'top-image' ) : ?>
								<?php include(locate_template('template-parts/elementor/content-top.php')); ?>
							<?php endif; ?>
							
							<?php if ( $settings['progression_elements_post_layout'] == 'overlay' ) : ?>
								<?php include(locate_template('template-parts/elementor/content-overlay.php')); ?>
							<?php endif; ?>
							
						</div><!-- close .progression-studios-isotope-animation -->
					</div><!-- close .progression-masonry-padding-blog -->
				</div><!-- close .progression-masonry-item -->
				<?php  endwhile; // end of the loop. ?>
			</div><!-- close #progression-review-index-masonry-<?php echo esc_attr($this->get_id()); ?>  -->
		</div><!-- close .progression-masonry-margins -->
		
		<div class="clearfix-pro"></div>
				<?php if ( $settings['progression_elements_post_list_pagination'] == 'default' ) : ?>
					<?php
			
					$page_tot = ceil(($blogloop->found_posts - $offset) / $post_per_page);
			
					if ( $page_tot > 1 ) {
					$big        = 999999999;
			      echo paginate_links( array(
			              'base'      => str_replace( $big, '%#%',get_pagenum_link( 999999999, false ) ), // need an unlikely integer cause the url can contains a number
			              'format'    => '?paged=%#%',
			              'current'   => max( 1, $paged ),
			              'total'     => ceil(($blogloop->found_posts - $offset) / $post_per_page),
			              'prev_next' => true,
			  				'prev_text'    => esc_html__('&lsaquo; Previous', 'progression-elements-ratency'),
			  				'next_text'    => esc_html__('Next &rsaquo;', 'progression-elements-ratency'),
			              'end_size'  => 1,
			              'mid_size'  => 2,
			              'type'      => 'list'
			          )
			      );
					}
					?>
				<?php endif; ?>

				<?php if ( $settings['progression_elements_post_list_pagination'] == 'load-more' ) : ?>
			
					<?php $page_tot = ceil(($blogloop->found_posts - $offset) / $post_per_page); if ( $page_tot > 1 ) : ?>
						<div id="progression-load-more-manual">
						<div id="infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?>" class="infinite-nav-pro"><div class="nav-previous"><?php next_posts_link( $settings['progression_main_post_load_more']
		. '<span><i class="fa ' . $settings['section_styles_load_more_icon'] . '"></i></span>', $blogloop->max_num_pages ); ?></div></div>
						</div>
					<?php endif ?>
				<?php endif; ?>
	
				<?php if ( $settings['progression_elements_post_list_pagination'] == 'infinite-scroll' ) : ?>
					<?php $page_tot = ceil(($blogloop->found_posts - $offset) / $post_per_page); if ( $page_tot > 1 ) : ?><div id="infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?>" class="infinite-nav-pro"><div class="nav-previous"><?php next_posts_link( 'Next', $blogloop->max_num_pages ); ?></div></div><?php endif ?>
				<?php endif; ?>
		
	</div><!-- close .progression-studios-elementor-review-container -->
	
	<div class="clearfix-pro"></div>
	
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		'use strict';
		/* Default Isotope Load Code */
		var $container<?php echo esc_attr($this->get_id()); ?> = $("#progression-review-index-masonry-<?php echo esc_attr($this->get_id()); ?>").isotope();
		$container<?php echo esc_attr($this->get_id()); ?>.imagesLoaded( function() {
			$(".progression-masonry-item").addClass("opacity-progression");
			$container<?php echo esc_attr($this->get_id()); ?>.isotope({
				itemSelector: "#progression-review-index-masonry-<?php echo esc_attr($this->get_id()); ?> .progression-masonry-item",				
				percentPosition: true,
				layoutMode: <?php if ( ! empty( $settings['boosted_post_list_masonry'] ) ) : ?>"masonry"<?php else: ?>"fitRows"<?php endif; ?> 
	 		});
		});
		/* END Default Isotope Code */
		
		<?php if( $settings['progression_elements_slider_sorting_on'] == 'yes' ||  $settings['progression_elements_category_sorting_on'] == 'yes'): ?>
		$('.progression-filter-group-<?php echo esc_attr($this->get_id()); ?>').on( 'click', 'li', function() {
		  var filterValue = $(this).attr('data-filter');
		  $container<?php echo esc_attr($this->get_id()); ?>.isotope({ filter: filterValue });
		});
		
    	  $('.progression-filter-group-<?php echo esc_attr($this->get_id()); ?>').each( function( i, buttonGroup ) {
    		var $buttonGroup = $( buttonGroup );
    		$buttonGroup.on( 'click', 'li', function() {
    		  $buttonGroup.find('.pro-checked').removeClass('pro-checked');
    		  $( this ).addClass('pro-checked');
    		});
    	  });
		<?php endif ?>
		
		
		<?php if ( $settings['progression_elements_post_list_pagination'] == 'infinite-scroll' || $settings['progression_elements_post_list_pagination'] == 'load-more' ) : ?>
		
		/* Begin Infinite Scroll */
		$container<?php echo esc_attr($this->get_id()); ?>.infinitescroll({
		errorCallback: function(){  $("#infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?>").delay(500).fadeOut(500, function(){ $(this).remove(); }); },
		  navSelector  : "#infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?>",  
		  nextSelector : "#infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?> .nav-previous a", 
		  itemSelector : "#progression-review-index-masonry-<?php echo esc_attr($this->get_id()); ?> .progression-masonry-item", 
	   		loading: {
	   		 	img: "<?php echo esc_url( get_template_directory_uri() );?>/images/loader.gif",
	   			 msgText: "",
	   		 	finishedMsg: "<div id='no-more-posts'></div>",
	   		 	speed: 0, }
		  },
		  // trigger Isotope as a callback
		  function( newElements ) {
			  
		     $(".progression-studios-gallery").flexslider({
		 		animation: "fade",      
		 		slideDirection: "horizontal", 
		 		slideshow: false,   
		 		smoothHeight: false,
		 		slideshowSpeed: 7000,  
		 		animationSpeed: 1000,        
		 		directionNav: true,             
		 		controlNav: true,
		 		prevText: "",   
		 		nextText: "",
		     });
			  
		    	$(".progression-studios-default-blog-overlay a[data-rel^=\'prettyPhoto\'], .progression-studios-feaured-image a[data-rel^=\'prettyPhoto\']").prettyPhoto({
		  			theme: "pp_default",
		    			hook: "data-rel",
		  			opacity: 0.7,
		    			show_title: false, 
		    			deeplinking: false,
		    			overlay_gallery: false,
		    			custom_markup: "",
		  			default_width: 1100,
		  			default_height: 619,
		    		social_tools:""
		    	});
				
				$(".progression-studios-default-blog-overlay, .progression-studios-default-blog-index").fitVids();
			  
		    var $newElems = $( newElements );
 	
				$newElems.imagesLoaded(function(){
					
				$container<?php echo esc_attr($this->get_id()); ?>.isotope( "appended", $newElems );
				$(".progression-masonry-item").addClass("opacity-progression");
				
			});

		  }
		);
	    /* END Infinite Scroll */
		<?php endif; ?>
		
		
		<?php if ( $settings['progression_elements_post_list_pagination'] == 'load-more' ) : ?>
		/* PAUSE FOR LOAD MORE */
		$(window).unbind(".infscr");
		// Resume Infinite Scroll
		$("#infinite-nav-pro-<?php echo esc_attr($this->get_id()); ?> .nav-previous a").click(function(){
			$container<?php echo esc_attr($this->get_id()); ?>.infinitescroll("retrieve");
			return false;
		});
		/* End Infinite Scroll */
		<?php endif; ?>
		
	});
	</script>
	

	<?php wp_reset_postdata();?>
	

	<?php
	
	}

	protected function content_template(){}
}


Plugin::instance()->widgets_manager->register_widget_type( new Widget_ProgressionElementsReviewList() );