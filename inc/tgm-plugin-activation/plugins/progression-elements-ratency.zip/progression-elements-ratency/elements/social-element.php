<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.


class Widget_ProgressionElementsSocialCounter extends Widget_Base {

	
	public function get_name() {
		return 'progression-episode-post-list';
	}

	public function get_title() {
		return esc_html__( 'Social Followers', 'progression-elements-ratency' );
	}

	public function get_icon() {
		return 'eicon-social-icons progression-studios-ratency-pe';
	}

   public function get_categories() {
		return [ 'progression-elements-ratency-cat' ];
	}
	
	
	function Widget_ProgressionElementsSocialCounter($widget_instance){
		
	}
	
	protected function _register_controls() {

		
  		$this->start_controls_section(
  			'section_title_global_options',
  			[
  				'label' => esc_html__( 'Social Counter Main', 'progression-elements-ratency' )
  			]
  		);
		
		$this->add_control(
			'progression_elements_social_counter',
			[
				'label' => '',
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'progression_elements_social_icon' => 'fa fa-facebook',
						'progression_elements_social_counter_title_field' => esc_html__( 'Facebook -', 'progression-elements-ratency' ),
						'progression_elements_social_descriptoin' => esc_html__( 'Fans', 'progression-elements-ratency' ),
						'progression_elements_social_fan_count_override' => esc_html__( '10.5k', 'progression-elements-ratency' ),
						'progression_elements_social_counter_divider' => '/',
					],
					[
						'progression_elements_social_icon' => 'fa fa-twitter',
						'progression_elements_social_counter_title_field' => esc_html__( 'Twitter -', 'progression-elements-ratency' ),
						'progression_elements_social_fan_count_override' => esc_html__( '6.8k', 'progression-elements-ratency' ),
						'progression_elements_social_descriptoin' => esc_html__( 'Followers', 'progression-elements-ratency' ),
						'progression_elements_social_counter_divider' => '/',
					],
					[
						'progression_elements_social_icon' => 'fa fa-youtube-play',
						'progression_elements_social_counter_title_field' => esc_html__( 'Youtube -', 'progression-elements-ratency' ),
						'progression_elements_social_fan_count_override' => esc_html__( '8.8k', 'progression-elements-ratency' ),
						'progression_elements_social_descriptoin' => esc_html__( 'Subs', 'progression-elements-ratency' ),
						'progression_elements_social_counter_divider' => '/',
					],
				],
				'fields' => [
					[
						'name' => 'progression_elements_social_icon',
						'label' => esc_html__( 'Icon', 'progression-elements-ratency' ),
						'type' => Controls_Manager::ICON,
						'label_block' => true,
					],
					[
						'name' => 'progression_elements_social_counter_title_field',
						'label' => esc_html__( 'Social Title', 'progression-elements-ratency' ),
						'type' => Controls_Manager::TEXT,
						'label_block' => true,
					],
					[
						'name' => 'progression_elements_social_descriptoin',
						'label' => esc_html__( 'Description', 'progression-elements-ratency' ),
						'type' => Controls_Manager::TEXT,
						'label_block' => true,
					],
					[
						'name' => 'progression_elements_social_counter_plugin',
						'label' => esc_html__( 'Automatic Subscriber Count', 'progression-elements-ratency' ),
						'description' => esc_html__( 'Automatically pull in social media subscriber counts from plugin. Settings > Social Count Plus', 'progression-elements-ratency' ),
						'type' => Controls_Manager::SELECT,
						'label_block' => true,
						'options' => [
							'' => 'Manually Add Count',
							'facebook' => esc_html__( 'Facebook', 'progression-elements-ratency' ),
							'twitter' => esc_html__( 'Twitter', 'progression-elements-ratency' ),
							'youtube' => esc_html__( 'Youtube', 'progression-elements-ratency' ),
							'googleplus' => esc_html__( 'Google+', 'progression-elements-ratency' ),
							'instagram' => esc_html__( 'Instagram', 'progression-elements-ratency' ),
							'steam' => esc_html__( 'Steam', 'progression-elements-ratency' ),
							'pinterest' => esc_html__( 'Pinterest', 'progression-elements-ratency' ),
							'tumblr' => esc_html__( 'Tumblr', 'progression-elements-ratency' ),
							'soundcloud' => esc_html__( 'Soundcloud', 'progression-elements-ratency' ),
							'posts' => esc_html__( 'Posts', 'progression-elements-ratency' ),
							'comments' => esc_html__( 'Comments', 'progression-elements-ratency' ),
						],
					],
					[
						'name' => 'progression_elements_social_fan_count_override',
						'label' => esc_html__( 'Optional Subscriber Count', 'progression-elements-ratency' ),
						'description' => esc_html__( 'Add-in a fan count manually isntead of plugin', 'progression-elements-ratency' ),
						'type' => Controls_Manager::TEXT,
						'label_block' => true,
					],
					[
						'name' => 'progression_elements_social_counter_divider',
						'label' => esc_html__( 'Divider', 'progression-elements-ratency' ),
						'type' => Controls_Manager::TEXT,
						'label_block' => true,
					],
					[
						'name' => 'progression_elements_social_counter_content_external_link',
						'label' => esc_html__( 'Optional Link', 'progression-elements-ratency' ),
						'placeholder' => 'http://progressionstudios.com',
						'type' => Controls_Manager::URL,
						'label_block' => true,
					],
					
				],
				'title_field' => '{{{ progression_elements_social_counter_title_field }}}',
			]
		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'boosted_elements_section_main_styles',
			[
				'label' => esc_html__( 'Main Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_content_align',
			[
				'label' => esc_html__( 'Text Align', 'progression-elements-ratency' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'progression-elements-ratency' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'progression-elements-ratency' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'progression-elements-ratency' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} ul.progression-studios-social-counter-container' => 'text-align: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_control(
			'progression_elements_text_color',
			[
				'label' => esc_html__( 'Social Counter Text Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-studios-social-counter-container h3, {{WRAPPER}} ul.progression-studios-social-counter-container a, {{WRAPPER}} ul.progression-studios-social-counter-container' => 'color: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'progression_elements_category_typography',
				'label' => esc_html__( 'Typography', 'progression-elements-ratency' ),
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} ul.progression-studios-social-counter-container h3, {{WRAPPER}} span.progression-elements-social-divider, {{WRAPPER}} .progression-elements-social-count-number',
			]
		);
		
		
		$this->end_controls_section();

		
		$this->start_controls_section(
			'boosted_elements_section_icon_styles',
			[
				'label' => esc_html__( 'Icon Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'progression_elements_icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-studios-social-counter-container i' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_control(
			'progression_elements_icon_background_color',
			[
				'label' => esc_html__( 'Icon Background', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ul.progression-studios-social-counter-container i' => 'background: {{VALUE}}',
				],
			]
		);
		
		
		$this->add_responsive_control(
			'boosted_elements_icon_size',
			[
				'label' => esc_html__( 'Icon Height/Width', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 80,
					],
				],
				'size_units' => [  'px' ],
				'default' => [
					'size' => '32',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} ul.progression-studios-social-counter-container i' => 'height: {{SIZE}}{{UNIT}}; line-height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_icon_text_size',
			[
				'label' => esc_html__( 'Icon Size', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 4,
						'max' => 50,
					],
				],
				'size_units' => [  'px' ],
				'default' => [
					'size' => '16',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} ul.progression-studios-social-counter-container i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_icon_margin_right',
			[
				'label' => esc_html__( 'Icon Margin Right', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'size_units' => [  'px' ],
				'default' => [
					'size' => '15',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} ul.progression-studios-social-counter-container i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_icon_vertical_height',
			[
				'label' => esc_html__( 'Icon Vertical Align', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => -30,
						'max' => 30,
					],
				],
				'size_units' => [  'px' ],
				'default' => [
					'size' => '4',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} ul.progression-studios-social-counter-container i' => 'top: {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		
		
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'boosted_elements_section_divider_styles',
			[
				'label' => esc_html__( 'Divider Styles', 'progression-elements-ratency' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		
		$this->add_control(
			'progression_elements_divider_color',
			[
				'label' => esc_html__( 'Divider Color', 'progression-elements-ratency' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} span.progression-elements-social-divider' => 'color: {{VALUE}}',
				],
			]
		);
		
		$this->add_responsive_control(
			'boosted_elements_divider_spacing',
			[
				'label' => esc_html__( 'Divider Spacing', 'progression-elements-ratency' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 80,
					],
				],
				'size_units' => [  'px' ],
				'default' => [
					'size' => '30',
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} span.progression-elements-social-divider' => 'padding:0px {{SIZE}}{{UNIT}};',
				],
			]
		);
		
		
		
		$this->end_controls_section();
		

		
	}
	

	protected function render( ) {
      $settings = $this->get_settings();
	?>
	
<div class="clearfix-pro"></div>
	
		<ul class="progression-studios-social-counter-container">	
			<?php foreach ( $settings['progression_elements_social_counter'] as $item ) :  ?>
				<li>
				
					<?php if ( ! empty( $item['progression_elements_social_counter_content_external_link']['url']) ) : ?><a href="<?php echo esc_url($item['progression_elements_social_counter_content_external_link']['url']); ?>" <?php if ( ! empty( $item['progression_elements_social_counter_content_external_link']['is_external'] ) ) : ?>target="_blank"<?php endif; ?> <?php if ( ! empty( $item['progression_elements_social_counter_content_external_link']['nofollow'] ) ) : ?>rel="nofollow"<?php endif; ?>><?php endif; ?>
					
						
						<?php if ( ! empty( $item['progression_elements_social_icon'] ) ) : ?>
							<i class="fa <?php echo esc_attr($item['progression_elements_social_icon'] ); ?> slide-button-align-icon-right" aria-hidden="true"></i>
						<?php endif; ?>
					
						<?php if ( ! empty( $item['progression_elements_social_counter_title_field']) ) : ?><h3 class="progression-elements-social-counter-title"><?php echo esc_attr($item['progression_elements_social_counter_title_field'] ); ?></h3><?php endif; ?>
						
						<?php if ( ! empty( $item['progression_elements_social_counter_plugin'] ) ) : ?>
							<div class="progression-elements-social-count-number">
							<?php 
							
								$total_number = GET_SCP_COUNTER($item['progression_elements_social_counter_plugin']);
								
								if ( $total_number > 1000000 ) {
									echo round( $total_number / 1000000, 1 ) . 'M';
								} else if ( $total_number > 1000 ) {
									echo round( $total_number / 1000, 1 ) . 'K';
								} else {
									echo $total_number;
								}
							
							?><?php if ( ! empty( $item['progression_elements_social_descriptoin']) ) : ?><span class="progression-elements-social-description"><?php echo wp_kses(($item['progression_elements_social_descriptoin'] ), true ); ?></span><?php endif; ?>
							</div>
						<?php else: ?>
							<?php if ( ! empty( $item['progression_elements_social_fan_count_override']) ) : ?><div class="progression-elements-social-count-number"><?php echo wp_kses(($item['progression_elements_social_fan_count_override'] ), true ); ?><?php if ( ! empty( $item['progression_elements_social_descriptoin']) ) : ?><span class="progression-elements-social-description"><?php echo wp_kses(($item['progression_elements_social_descriptoin'] ), true ); ?></span><?php endif; ?></div><?php endif; ?>
						<?php endif; ?>
						
						
						
						
			
						<?php if ( ! empty( $item['progression_elements_social_counter_divider']) ) : ?><span class="progression-elements-social-divider"><?php echo wp_kses(($item['progression_elements_social_counter_divider'] ), true ); ?></span><?php endif; ?>
				
					<div class="clearfix-pro"></div>
					<?php if ( ! empty( $item['progression_elements_social_counter_content_external_link']) ) : ?></a><?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul><!-- close .progression-studios-social-counter-container -->
	
<div class="clearfix-pro"></div>
	<?php
	
	}

	protected function content_template(){}
}


Plugin::instance()->widgets_manager->register_widget_type( new Widget_ProgressionElementsSocialCounter() );