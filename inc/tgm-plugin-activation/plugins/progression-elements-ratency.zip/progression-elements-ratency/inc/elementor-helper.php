<?php
namespace Elementor;

function progression_ratency_elements_elementor_init(){
    Plugin::instance()->elements_manager->add_category(
        'progression-elements-ratency-cat',
        [
            'title'  => 'Ratency Addons',
            'icon' => 'font'
        ],
        1
    );
}
add_action('elementor/init','Elementor\progression_ratency_elements_elementor_init');



//Query Categories List
function ratency_elements_post_type_categories(){
	//https://developer.wordpress.org/reference/functions/get_terms/
	$terms = get_terms( array( 
		'taxonomy' => 'category',
		'hide_empty' => true,
	));
	
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
	foreach ( $terms as $term ) {
		$options[ $term->term_id ] = $term->name;
	}
	}
	
	return $options;
}


function ratency_elements_post_type_slider_tags(){
	//https://developer.wordpress.org/reference/functions/get_terms/
	$terms = get_terms( array( 
		'taxonomy' => 'slider-tags',
		'hide_empty' => true,
	));
	
	if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
	foreach ( $terms as $term ) {
		$options[ $term->term_id ] = $term->name;
	}
	}
	
	return $options;
}

